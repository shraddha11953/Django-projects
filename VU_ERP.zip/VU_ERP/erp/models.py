from django.db import models



# Create your models here.
class students(models.Model):
    first_name= models.CharField(max_length=50,null=False)
    last_name=models.CharField(max_length=50)
    username= models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    
    percentage=models.IntegerField(default=0)
    phone=models.IntegerField(default=0)
    

    def __str__(self):
        return "%s %s  %s" %(self.first_name,self.username,self.password,)


