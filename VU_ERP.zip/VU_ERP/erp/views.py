from django.shortcuts import render, HttpResponse,redirect
from .models import students
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login


# Create your views here.
def index(request):
    return render(request,'index.html')


def about(request):
    stus = students.objects.all()
    context = {
        'stus': stus

    }
    print(context)
    return render(request,'about-us.html', context)
    

def login(request):
    stus = students.objects.all()
    context = {
        'stus': stus

    }
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        for stu in stus:
            if username == stu.username:
                if password == stu.password:
                    return render(request,'erp.html')
                    
                
        
        return render(request,'login.html')
    

def register(request):
    if request.method =='POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        percentage = int(request.POST['percentage'])
    
        phone =int( request.POST['phone'])
       

        stu = students(first_name=first_name, last_name=last_name, username=username, password=password, percentage=percentage, phone=phone )
        stu.save()

        return render(request,'login.html')

    elif request.method=='GET':
         return render(request,'register.html')
    
    else:
        return HttpResponse("exception")

    