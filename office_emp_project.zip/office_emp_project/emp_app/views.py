from django.shortcuts import render, HttpResponse
from .models import Employee,Role,Department
from datetime import datetime
from django.db.models import Q

# Create your views here.
def index(request):
    return render(request,'index.html')

def all_employee(request):
    emps = Employee.objects.all()
    context = {
        'emps': emps

    }
    print(context)
    return render(request,'all_employee.html', context)

def add_employee(request):
    if request.method =='POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        Department = int(request.POST['Department'])
        
        salary =int(request.POST['salary'])
        Bonus = int(request.POST['Bonus'])
        Role = request.POST['Role']
        Phone =int( request.POST['Phone'])
        

        new_emp = Employee(first_name=first_name, last_name=last_name, Department_id = Department, salary=salary,Bonus=Bonus,Role_id=Role,Phone=Phone,Date=datetime.now() )
        new_emp.save()

        return HttpResponse("employee added sucessfully")

    elif request.method=='GET':
         return render(request,'add_employee.html')
    
    else:
        return HttpResponse("exception")

        
    

   

def remove_employee(request, emp_id=0):
    if emp_id:
        try:
            emp_to_be_removed =    Employee.objects.get(id=emp_id)
            emp_to_be_removed.delete()
            return HttpResponse("succesfully deleted employee")
            pass
        except:
            return HttpResponse("please enter valid emp_id")
    emps = Employee.objects.all()
    context = {
        'emps': emps

    }
    return render(request,'remove_employee.html',context)

def filter_employee(request):
    if request.method == 'POST':
        name = request.POST['name']
        Department = request.POST['Department']
        Role = request.POST['Role']
        emps = Employee.objects.all()

        if name:
            emps = emps.filter(Q(first_name__icontains = name) | Q(last_name__icontains = name))
            
        if Department:
            emps = emps.filter(Department__name__contains = Department)
            
        if Role:
            emps = emps.filter(Role__name_contains = Role)
            

        context = {
            'emps': emps
        }

        return render(request,'all_employee.html', context)
    elif request.method == 'GET':
        return render(request,'filter_employee.html')
    else:
        return HttpResponse("invalid response")


    
